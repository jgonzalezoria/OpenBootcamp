package com.jgonzalezoria.obspringsecuritycifrado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObSpringSecurityCifradoApplicationTests {

	@Test
	void contextLoads() {
	}

}
