package com.jgonzalezoria.obspringsecuritycifrado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObSpringSecurityCifradoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObSpringSecurityCifradoApplication.class, args);
	}

}
