package com.jgonzalezoria.EjercicioSesion456;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioSesion456Application {

	public static void main(String[] args) {
		SpringApplication.run(EjercicioSesion456Application.class, args);
	}

}
