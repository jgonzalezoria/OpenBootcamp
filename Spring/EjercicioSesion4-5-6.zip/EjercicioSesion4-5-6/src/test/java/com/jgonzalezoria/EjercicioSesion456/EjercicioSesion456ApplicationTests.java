package com.jgonzalezoria.EjercicioSesion456;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioSesion456ApplicationTests {

	@Test
	void contextLoads() {
	}

}
