package com.jgonzalezoria.EjercicioSesion3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioSesion3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
