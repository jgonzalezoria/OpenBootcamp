package com.jgonzalezorai.obspringapirestlaptop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObSpringApiRestLaptopApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObSpringApiRestLaptopApplication.class, args);
	}

}
