package com.jgonzalezorai.obspringapirestlaptop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObSpringApiRestLaptopApplicationTests {

	@Test
	void contextLoads() {
	}

}
